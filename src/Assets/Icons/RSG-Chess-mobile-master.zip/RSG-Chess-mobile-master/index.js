import { AppRegistry } from 'react-native';
import App from './App';

console.disableYellowBox = true;
AppRegistry.registerComponent('RSG_Chess_mobile_native', () => App);
