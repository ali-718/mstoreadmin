import React from "react";

const NavigationContext = React.createContext("test");
export default NavigationContext;
